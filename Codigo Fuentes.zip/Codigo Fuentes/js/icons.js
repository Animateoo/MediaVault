/**
 * MediaVault by Animateoo — SVG icons
 */
const MediaVaultIcons = (function () {
    const svgs = {
        list:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">' +
            '<line x1="2" y1="4" x2="14" y2="4"/><line x1="2" y1="8" x2="14" y2="8"/><line x1="2" y1="12" x2="10" y2="12"/>' +
            "</svg>",
        grid:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="14" height="14" fill="currentColor">' +
            '<rect x="2" y="2" width="5" height="5" rx="1"/><rect x="9" y="2" width="5" height="5" rx="1"/>' +
            '<rect x="2" y="9" width="5" height="5" rx="1"/><rect x="9" y="9" width="5" height="5" rx="1"/>' +
            "</svg>",
        star:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round">' +
            '<path d="M8 2.2l1.6 3.4 3.6.6-2.6 2.5.6 3.6L8 10.9l-3.2 1.8.6-3.6-2.6-2.5 3.6-.6L8 2.2z"/>' +
            "</svg>",
        starFill:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="14" height="14" fill="currentColor" stroke="currentColor" stroke-width="0.5">' +
            '<path d="M8 1.8l2 4.1 4.5.7-3.2 3.2.8 4.5L8 11.6 4 14.3l.8-4.5L1.5 6.6l4.5-.7L8 1.8z"/>' +
            "</svg>",
        play:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="12" height="12" fill="currentColor">' +
            '<path d="M5 3.5v9l7.5-4.5L5 3.5z"/>' +
            "</svg>",
        pause:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="12" height="12" fill="currentColor">' +
            '<rect x="4" y="3" width="3" height="10" rx="0.5"/><rect x="9" y="3" width="3" height="10" rx="0.5"/>' +
            "</svg>",
        audio:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round">' +
            '<path d="M3 10V6.5a2 2 0 0 1 4 0V10a2 2 0 0 1-4 0z"/>' +
            '<path d="M7 7.5V4.2a2.5 2.5 0 0 1 5 0V10a2 2 0 0 1-4 0"/>' +
            "</svg>",
        video:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round">' +
            '<rect x="2" y="4" width="9" height="8" rx="1.2"/>' +
            '<path d="M11 7l3-1.5v5L11 9V7z" fill="currentColor" stroke="none"/>' +
            "</svg>",
        image:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round">' +
            '<rect x="2" y="3" width="12" height="10" rx="1.2"/>' +
            '<circle cx="5.5" cy="6.5" r="1.2" fill="currentColor" stroke="none"/>' +
            '<path d="M3 12l3.5-3 2.5 2 2-1.5L13 12"/>' +
            "</svg>",
        file:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round">' +
            '<path d="M5 2h4l3 3v9H5V2z"/><path d="M9 2v3h3"/>' +
            "</svg>",
        importIn:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M8 3v6"/><path d="M5.5 7.5L8 10l2.5-2.5"/><path d="M3 13h10"/>' +
            "</svg>",
        timeline:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M2 5.5h10"/><path d="M2 9.5h6"/><path d="M13 7.5v4"/><path d="M11 9.5h4"/>' +
            "</svg>",
        volume:
            '<svg class="mv-icon" viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M3 6v4h2l3 2.5V3.5L5 6H3z"/>' +
            '<path d="M10.5 6.5a2.5 2.5 0 0 1 0 3"/><path d="M12 4.5a5 5 0 0 1 0 7"/>' +
            "</svg>",
        chevron:
            '<svg class="mv-icon mv-chevron" viewBox="0 0 16 16" width="10" height="10" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M6 4l4 4-4 4"/>' +
            "</svg>"
    };

    function html(name) {
        return svgs[name] || svgs.file;
    }

    function typeHtml(type) {
        const map = {
            video: "video",
            audio: "audio",
            image: "image",
            project: "file",
            preset: "file",
            other: "file"
        };
        return html(map[type] || "file");
    }

    function starHtml(on) {
        return on ? html("starFill") : html("star");
    }

    function setPlayState(btn, playing) {
        if (!btn) return;
        btn.innerHTML = playing ? html("pause") : html("play");
        btn.setAttribute("aria-label", playing ? "Pausar" : "Reproducir");
    }

    function mountTypeIcon(el, type) {
        if (!el) return;
        el.innerHTML = typeHtml(type);
    }

    return {
        html: html,
        typeHtml: typeHtml,
        starHtml: starHtml,
        setPlayState: setPlayState,
        mountTypeIcon: mountTypeIcon
    };
})();
