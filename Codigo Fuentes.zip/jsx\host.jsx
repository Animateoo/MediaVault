/*
Â© Mateo Crespo (Animateo)

Puedes usar este plugin libremente.
No puedes venderlo, redistribuirlo ni publicar versiones modificadas.

Â¿Encontraste una mejora o correcciÃ³n?
Por favor, compÃ¡rtela con el autor.
*/

/* MediaVault by Animateoo — ExtendScript host (After Effects + Premiere Pro) */

function mvJsonEscape(str) {
    return String(str)
        .replace(/\\/g, "\\\\")
        .replace(/"/g, '\\"')
        .replace(/\r/g, "\\r")
        .replace(/\n/g, "\\n");
}

function mvGetHostInfo() {
    var isPPRO = mvIsPPRO();
    var isAE = mvIsAE();
    var name = "";
    try {
        name = BridgeTalk.appName;
    } catch (e) {
        name = isPPRO ? "premierepro" : isAE ? "aftereffects" : "unknown";
    }
    return '{"host":"' + mvJsonEscape(name) + '","isPPRO":' + (isPPRO ? "true" : "false") + ',"isAE":' + (isAE ? "true" : "false") + '}';
}

function mvGetProjectFolderAE() {
    try {
        if (!app.project || !app.project.file) return "";
        return app.project.file.parent.fsName;
    } catch (e) {}
    return "";
}

function mvGetProjectFolderPPRO() {
    try {
        if (!app.project || !app.project.path) return "";
        var f = new File(app.project.path);
        if (f.parent) return f.parent.fsName;
    } catch (e) {}
    return "";
}

function mvGetProjectFolder() {
    if (mvIsPPRO()) return mvGetProjectFolderPPRO();
    return mvGetProjectFolderAE();
}

// ─── After Effects ───────────────────────────────────────────────

function mvActiveCompAE() {
    if (!app.project) return null;
    var item = app.project.activeItem;
    if (item instanceof CompItem) return item;
    return null;
}

function mvForEachProjectItemAE(callback) {
    function walk(folder) {
        var i, item;
        for (i = 1; i <= folder.numItems; i++) {
            item = folder.item(i);
            if (item instanceof FolderItem) {
                walk(item);
            } else {
                callback(item);
            }
        }
    }

    if (!app.project || !app.project.rootFolder) return;
    walk(app.project.rootFolder);
}

function mvGetFootagePathAE(item) {
    if (!(item instanceof FootageItem)) return "";

    try {
        if (item.mainSource && item.mainSource.file) {
            return mvNormalizePath(item.mainSource.file.fsName);
        }
    } catch (e1) {}

    try {
        if (item.file) return mvNormalizePath(item.file.fsName);
    } catch (e2) {}

    return "";
}

function mvFindFootageByPathAE(mediaPath) {
    var target = mvNormalizePath(mediaPath).toLowerCase();
    var found = null;

    if (!target) return null;

    mvForEachProjectItemAE(function (item) {
        if (found || !(item instanceof FootageItem)) return;
        try {
            if (mvGetFootagePathAE(item).toLowerCase() === target) found = item;
        } catch (e) {}
    });

    return found;
}

function mvFindFootageByNameAE(fileName) {
    var found = null;

    if (!fileName) return null;

    mvForEachProjectItemAE(function (item) {
        if (found || !(item instanceof FootageItem)) return;
        try {
            if (item.name === fileName) found = item;
        } catch (e) {}
    });

    return found;
}

function mvFindExistingImportAE(filePath, sourcePath) {
    var normalized = mvNormalizePath(filePath);
    var sourceNorm = mvNormalizePath(sourcePath || filePath);
    var fileName = mvFileBaseName(sourceNorm);
    var found;

    found = mvFindFootageByPathAE(normalized);
    if (found) return found;

    found = mvFindFootageByPathAE(sourceNorm);
    if (found) return found;

    return mvFindFootageByNameAE(fileName);
}

function mvFootageTypeAE(item) {
    var type = "footage";

    if (item instanceof CompItem) type = "comp";
    else if (item instanceof FootageItem) {
        try {
            type = item.mainSource.isStill ? "image" : (item.hasVideo ? "video" : "audio");
        } catch (e2) {
            type = "footage";
        }
    }

    return type;
}

function mvExistingImportJsonAE(item, alreadyImported) {
    var flag = alreadyImported ? ',"alreadyImported":true' : "";
    return '{"ok":true,"type":"' + mvFootageTypeAE(item) + '","id":' + item.id + ',"name":"' + mvJsonEscape(item.name) + '"' + flag + "}";
}

function mvGetTopSelectedLayerIndexAE(comp) {
    if (!comp || !comp.selectedLayers || comp.selectedLayers.length === 0) {
        return 0;
    }
    var topIndex = comp.selectedLayers[0].index;
    var i;
    for (i = 1; i < comp.selectedLayers.length; i++) {
        if (comp.selectedLayers[i].index < topIndex) {
            topIndex = comp.selectedLayers[i].index;
        }
    }
    return topIndex;
}

function mvResolveInsertIndexAE(comp, preferredIndex) {
    var idx = parseInt(preferredIndex, 10);
    if (!isNaN(idx) && idx > 0) {
        var maxIndex = comp.numLayers + 1;
        if (idx > maxIndex) idx = maxIndex;
        return idx;
    }
    idx = mvGetTopSelectedLayerIndexAE(comp);
    return idx > 0 ? idx : 1;
}

function mvGetSelectedLayerIndexAE() {
    var comp = mvActiveCompAE();
    if (!comp) {
        return '{"ok":false,"error":"no_active_comp"}';
    }
    return '{"ok":true,"index":' + mvGetTopSelectedLayerIndexAE(comp) + ',"comp":"' + mvJsonEscape(comp.name) + '"}';
}

function mvImportFootageAE(filePath, sourcePath) {
    if (!app.project) return '{"ok":false,"error":"no_project"}';
    var normalized = mvNormalizePath(filePath);
    var sourceNorm = mvNormalizePath(sourcePath || filePath);
    var f = new File(normalized);
    if (!f.exists) return '{"ok":false,"error":"file_not_found"}';

    app.beginUndoGroup("MediaVault Import");
    try {
        var ext = f.name.split(".").pop().toLowerCase();
        var io = new ImportOptions(f);
        var item;
        var existing;

        if (ext === "ffx") {
            app.endUndoGroup();
            return '{"ok":false,"error":"use_preset_flow"}';
        }

        if (ext === "aep" || ext === "aepx") {
            if (!io.canImportAs(ImportAsType.PROJECT)) {
                app.endUndoGroup();
                return '{"ok":false,"error":"invalid_project"}';
            }
            io.importAs = ImportAsType.PROJECT;
            item = app.project.importFile(io);
            app.endUndoGroup();
            return '{"ok":true,"type":"project","name":"' + mvJsonEscape(f.displayName) + '"}';
        }

        existing = mvFindExistingImportAE(normalized, sourceNorm);
        if (existing) {
            app.endUndoGroup();
            return mvExistingImportJsonAE(existing, true);
        }

        if (io.canImportAs(ImportAsType.FOOTAGE)) {
            io.importAs = ImportAsType.FOOTAGE;
        }
        item = app.project.importFile(io);
        if (!item) {
            app.endUndoGroup();
            return '{"ok":false,"error":"import_failed"}';
        }

        app.endUndoGroup();
        return mvExistingImportJsonAE(item, false);
    } catch (e) {
        app.endUndoGroup();
        return '{"ok":false,"error":"' + mvJsonEscape(String(e)) + '"}';
    }
}

function mvAddToTimelineAE(filePath, sourcePath, layerIndex) {
    var res = mvImportFootageAE(filePath, sourcePath);
    if (res.indexOf('"ok":false') >= 0) return res;

    var comp = mvActiveCompAE();
    if (!comp) {
        if (res.indexOf('"type":"comp"') >= 0 || res.indexOf('"type":"project"') >= 0) {
            return res;
        }
        return '{"ok":false,"error":"no_active_comp"}';
    }

    var idMatch = res.match(/"id":(\d+)/);
    if (!idMatch) return res;

    app.beginUndoGroup("MediaVault Add to Timeline");
    try {
        var footage = app.project.itemByID(parseInt(idMatch[1], 10));
        if (!footage) {
            app.endUndoGroup();
            return '{"ok":false,"error":"item_not_found"}';
        }

        var insertAt = mvResolveInsertIndexAE(comp, layerIndex);
        var layer = comp.layers.add(footage, insertAt);
        layer.startTime = comp.time;

        if (layer instanceof AVLayer && footage instanceof FootageItem) {
            try {
                if (!footage.mainSource.isStill && footage.duration > 0) {
                    layer.outPoint = layer.inPoint + footage.duration;
                }
            } catch (durErr) {}
        }

        app.endUndoGroup();
        return res.replace('"ok":true', '"ok":true,"addedToTimeline":true');
    } catch (e) {
        app.endUndoGroup();
        return '{"ok":false,"error":"' + mvJsonEscape(String(e)) + '"}';
    }
}

function mvApplyPresetAE(filePath) {
    var comp = mvActiveCompAE();
    if (!comp) return '{"ok":false,"error":"no_active_comp"}';
    if (!comp.selectedLayers || comp.selectedLayers.length === 0) {
        return '{"ok":false,"error":"select_layer"}';
    }

    var f = new File(filePath);
    if (!f.exists) return '{"ok":false,"error":"file_not_found"}';

    app.beginUndoGroup("MediaVault Preset");
    try {
        var layer = comp.selectedLayers[0];
        var parade = layer.property("ADBE Effect Parade");
        if (!parade) {
            app.endUndoGroup();
            return '{"ok":false,"error":"no_effects"}';
        }
        parade.applyPreset(f);
        app.endUndoGroup();
        return '{"ok":true,"type":"preset","name":"' + mvJsonEscape(f.displayName) + '"}';
    } catch (e) {
        app.endUndoGroup();
        return '{"ok":false,"error":"' + mvJsonEscape(String(e)) + '"}';
    }
}

// ─── Premiere Pro ────────────────────────────────────────────────

function mvIsAudioExt(ext) {
    var list = ["wav", "mp3", "aiff", "aif", "aac", "m4a", "ogg", "flac", "wma", "caf"];
    var i;
    ext = String(ext || "").toLowerCase();
    for (i = 0; i < list.length; i++) {
        if (list[i] === ext) return true;
    }
    return false;
}

function mvFindBinPPRO(binName) {
    if (!app.project || !app.project.rootItem) return null;
    var root = app.project.rootItem.children;
    var i, item;
    for (i = 0; i < root.numItems; i++) {
        item = root[i];
        if (item.type === ProjectItemType.BIN && item.name === binName) return item;
    }
    return app.project.rootItem.createBin(binName);
}

function mvFileBaseName(filePath) {
    var normalized = mvNormalizePath(filePath);
    var parts = normalized.split("/");
    return parts[parts.length - 1] || normalized;
}

function mvFindItemByMediaPathPPRO(container, mediaPath) {
    var target = mvNormalizePath(mediaPath).toLowerCase();
    var i, item, mp, nested;

    if (!container || !container.children || !target) return null;

    for (i = 0; i < container.children.numItems; i++) {
        item = container.children[i];
        try {
            if (item.type === ProjectItemType.BIN) {
                nested = mvFindItemByMediaPathPPRO(item, mediaPath);
                if (nested) return nested;
                continue;
            }
            mp = mvNormalizePath(item.getMediaPath()).toLowerCase();
            if (mp === target) return item;
        } catch (e1) {}
    }
    return null;
}

function mvFindExactInBinPPRO(bin, filePath) {
    var fileName = mvFileBaseName(filePath);
    var i, item;

    if (!bin || !bin.children) return null;

    for (i = 0; i < bin.children.numItems; i++) {
        item = bin.children[i];
        if (item.name === fileName) return item;
    }
    return null;
}

function mvFindImportedItemPPRO(bin, filePath, countBefore) {
    var byPath = mvFindItemByMediaPathPPRO(bin, filePath);
    if (byPath) return byPath;

    var fileName = mvFileBaseName(filePath);
    var i, item;

    if (bin && bin.children) {
        for (i = countBefore; i < bin.children.numItems; i++) {
            item = bin.children[i];
            if (item.name === fileName) return item;
        }
        for (i = countBefore; i < bin.children.numItems; i++) {
            return bin.children[i];
        }
    }

    return mvFindExactInBinPPRO(bin, filePath);
}

function mvIsClipItemPPRO(item) {
    if (!item) return false;
    try {
        return item.type === ProjectItemType.CLIP;
    } catch (e) {
        return false;
    }
}

function mvFindItemByNameRecursivePPRO(container, fileName) {
    var i, item, found;
    if (!container || !container.children || !fileName) return null;
    for (i = 0; i < container.children.numItems; i++) {
        item = container.children[i];
        try {
            if (item.type === ProjectItemType.BIN) {
                found = mvFindItemByNameRecursivePPRO(item, fileName);
                if (found) return found;
            } else if (item.name === fileName && mvIsClipItemPPRO(item)) {
                return item;
            }
        } catch (e1) {}
    }
    return null;
}

function mvFindExistingImportPPRO(bin, filePath, sourcePath) {
    var normalized = mvNormalizePath(filePath);
    var sourceNorm = mvNormalizePath(sourcePath || filePath);
    var fileName = mvFileBaseName(sourceNorm);
    var found;

    found = mvFindItemByMediaPathPPRO(bin, normalized);
    if (found && mvIsClipItemPPRO(found)) return found;

    found = mvFindItemByMediaPathPPRO(bin, sourceNorm);
    if (found && mvIsClipItemPPRO(found)) return found;

    found = mvFindItemByMediaPathPPRO(app.project.rootItem, normalized);
    if (found && mvIsClipItemPPRO(found)) return found;

    found = mvFindItemByMediaPathPPRO(app.project.rootItem, sourceNorm);
    if (found && mvIsClipItemPPRO(found)) return found;

    found = mvFindItemByNameRecursivePPRO(bin, fileName);
    if (found) return found;

    return mvFindItemByNameRecursivePPRO(app.project.rootItem, fileName);
}

function mvExistingImportJson(item, alreadyImported) {
    var flag = alreadyImported ? ',"alreadyImported":true' : "";
    return '{"ok":true,"type":"clip","name":"' + mvJsonEscape(item.name) + '","nodeId":"' + mvJsonEscape(String(item.nodeId)) + '"' + flag + "}";
}

function mvSleepMs(ms) {
    try {
        $.sleep(ms);
    } catch (e) {}
}

function mvCanInsertClipPPRO(track, startTime, duration) {
    var i, clip, clipStart, clipEnd;

    if (!track || !track.clips) return true;
    duration = duration || 1;

    try {
        for (i = 0; i < track.clips.numItems; i++) {
            clip = track.clips[i];
            clipStart = clip.start.seconds;
            clipEnd = clip.end.seconds;
            if (startTime >= clipStart && startTime < clipEnd) return false;
            if (startTime + duration > clipStart && startTime + duration <= clipEnd) return false;
            if (startTime <= clipStart && startTime + duration >= clipEnd) return false;
        }
    } catch (e) {}

    return true;
}

function mvTryInsertOnTracksPPRO(tracks, projectItem, insertionTime) {
    var i;

    if (!tracks || tracks.numTracks < 1) return false;

    for (i = 0; i < tracks.numTracks; i++) {
        if (!mvCanInsertClipPPRO(tracks[i], insertionTime, 1)) continue;
        try {
            tracks[i].insertClip(projectItem, insertionTime);
            return true;
        } catch (e) {}
    }

    return false;
}

function mvInsertOnTrackPPRO(sequence, projectItem, preferAudio) {
    var insertionTime, inserted, qeSequence, tracks;

    if (!sequence || !projectItem || !mvIsClipItemPPRO(projectItem)) return false;

    try {
        insertionTime = sequence.getPlayerPosition().seconds;
    } catch (e) {
        insertionTime = 0;
    }

    inserted = false;

    if (preferAudio) {
        try {
            inserted = mvTryInsertOnTracksPPRO(sequence.audioTracks, projectItem, insertionTime);
        } catch (eAudio) {}
    }

    if (!inserted) {
        try {
            inserted = mvTryInsertOnTracksPPRO(sequence.videoTracks, projectItem, insertionTime);
        } catch (eVideo) {}
    }

    if (!inserted && !preferAudio) {
        try {
            inserted = mvTryInsertOnTracksPPRO(sequence.audioTracks, projectItem, insertionTime);
        } catch (eAudio2) {}
    }

    if (!inserted) {
        try {
            app.enableQE();
            if (typeof qe !== "undefined" && qe.project) {
                qeSequence = qe.project.getActiveSequence();
                if (qeSequence) {
                    qeSequence.addTracks(1, sequence.videoTracks.numTracks);
                    tracks = sequence.videoTracks;
                    tracks[sequence.videoTracks.numTracks - 1].insertClip(projectItem, insertionTime);
                    inserted = true;
                }
            }
        } catch (eQE) {}
    }

    return inserted;
}

function mvResolveImportItemPPRO(bin, normalized, sourceNorm, res, freshImport) {
    var imported, nodeMatch, i;

    if (freshImport) {
        mvSleepMs(300);
    }

    for (i = 0; i < 5; i++) {
        nodeMatch = res.match(/"nodeId":"([^"]+)"/);
        if (nodeMatch) {
            imported = mvFindItemByNodeIdPPRO(nodeMatch[1]);
            if (imported && mvIsClipItemPPRO(imported)) return imported;
        }

        imported = mvFindExistingImportPPRO(bin, normalized, sourceNorm);
        if (imported && mvIsClipItemPPRO(imported)) return imported;

        if (freshImport && i < 4) {
            mvSleepMs(180);
        }
    }

    return null;
}

function mvNormalizePath(filePath) {
    return String(filePath || "").replace(/\\/g, "/");
}

function mvImportFilesPPRO(filePath, bin) {
    var paths = [mvNormalizePath(filePath)];
    try {
        return app.project.importFiles(paths, true, bin, false) === true;
    } catch (e1) {
        return false;
    }
}

function mvImportFootagePPRO(filePath, sourcePath) {
    if (!app.project) return '{"ok":false,"error":"no_project"}';
    var normalized = mvNormalizePath(filePath);
    var sourceNorm = mvNormalizePath(sourcePath || filePath);
    var f = new File(normalized);
    if (!f.exists) return '{"ok":false,"error":"file_not_found"}';

    try {
        var bin = mvFindBinPPRO("MediaVault");
        if (!bin) {
            return '{"ok":false,"error":"import_failed"}';
        }

        var existing = mvFindExistingImportPPRO(bin, normalized, sourceNorm);
        if (existing) {
            return mvExistingImportJson(existing, true);
        }

        var countBefore = bin.children.numItems;
        if (!mvImportFilesPPRO(normalized, bin)) {
            return '{"ok":false,"error":"import_failed"}';
        }

        var imported = mvFindImportedItemPPRO(bin, normalized, countBefore);
        if (!imported) {
            imported = mvFindExistingImportPPRO(bin, normalized, sourceNorm);
        }
        if (!imported || !mvIsClipItemPPRO(imported)) {
            return '{"ok":false,"error":"import_failed"}';
        }

        return mvExistingImportJson(imported, false);
    } catch (e) {
        return '{"ok":false,"error":"' + mvJsonEscape(String(e)) + '"}';
    }
}

function mvFindItemByNodeIdPPRO(nodeId) {
    if (!nodeId || !app.project || !app.project.rootItem) return null;

    function walk(item) {
        var i, child, found;
        if (!item) return null;
        try {
            if (String(item.nodeId) === String(nodeId)) return item;
        } catch (e0) {}
        if (item.children) {
            for (i = 0; i < item.children.numItems; i++) {
                child = item.children[i];
                found = walk(child);
                if (found) return found;
            }
        }
        return null;
    }

    return walk(app.project.rootItem);
}

function mvInsertToTimelinePPRO(filePath, sourcePath, nodeId) {
    var sequence = app.project.activeSequence;
    if (!sequence) return '{"ok":false,"error":"no_active_sequence"}';

    var normalized = mvNormalizePath(filePath);
    var sourceNorm = mvNormalizePath(sourcePath || filePath);
    var bin = mvFindBinPPRO("MediaVault");
    var imported = null;
    var ext, preferAudio, inserted;

    if (nodeId) imported = mvFindItemByNodeIdPPRO(nodeId);
    if (!imported || !mvIsClipItemPPRO(imported)) {
        imported = mvFindExistingImportPPRO(bin, normalized, sourceNorm);
    }
    if (!imported || !mvIsClipItemPPRO(imported)) {
        return '{"ok":false,"error":"item_not_found"}';
    }

    ext = normalized.split(".").pop();
    preferAudio = mvIsAudioExt(ext);
    inserted = mvInsertOnTrackPPRO(sequence, imported, preferAudio);

    if (!inserted) {
        return '{"ok":false,"error":"insert_failed","name":"' + mvJsonEscape(imported.name) + '"}';
    }
    return '{"ok":true,"addedToTimeline":true,"name":"' + mvJsonEscape(imported.name) + '"}';
}

function mvAddToTimelinePPRO(filePath, sourcePath) {
    return mvImportFootagePPRO(mvNormalizePath(filePath), mvNormalizePath(sourcePath || filePath));
}

// ─── Unified API ─────────────────────────────────────────────────

function mvIsPPRO() {
    try {
        if (typeof app === "undefined" || !app.project) return false;
        return typeof app.project.activeSequence !== "undefined";
    } catch (e) {
        return false;
    }
}

function mvIsAE() {
    try {
        if (typeof app === "undefined" || !app.project) return false;
        return typeof app.project.activeSequence === "undefined";
    } catch (e) {
        return false;
    }
}

function mvImportMedia(filePath, addToTimeline, sourcePath, layerIndex) {
    filePath = mvNormalizePath(filePath);
    sourcePath = mvNormalizePath(sourcePath || filePath);
    var ext = filePath.split(".").pop().toLowerCase();
    var toTimeline = addToTimeline === true || addToTimeline === "true";

    if (ext === "ffx") {
        if (mvIsPPRO()) {
            return '{"ok":false,"error":"ffx_not_supported_ppro"}';
        }
        return mvApplyPresetAE(filePath);
    }

    if (mvIsPPRO()) {
        return toTimeline ? mvAddToTimelinePPRO(filePath, sourcePath) : mvImportFootagePPRO(filePath, sourcePath);
    }

    return toTimeline
        ? mvAddToTimelineAE(filePath, sourcePath, layerIndex)
        : mvImportFootageAE(filePath, sourcePath);
}

function mvRun(payloadJson) {
    try {
        var data = JSON.parse(payloadJson);
        var action = data.action || "";

        if (action === "importMedia") {
            return mvImportMedia(
                data.path,
                !!data.addToTimeline,
                data.sourcePath || data.path,
                data.layerIndex
            );
        }
        if (action === "getSelectedLayerIndex") {
            return mvGetSelectedLayerIndexAE();
        }
        if (action === "insertToTimeline") {
            return mvInsertToTimelinePPRO(
                data.path,
                data.sourcePath || data.path,
                data.nodeId || ""
            );
        }
        if (action === "getHostInfo") {
            return mvGetHostInfo();
        }
        if (action === "getProjectFolder") {
            var folder = mvGetProjectFolder();
            return '{"ok":true,"path":"' + mvJsonEscape(folder) + '"}';
        }

        return '{"ok":false,"error":"unknown_action"}';
    } catch (e) {
        return '{"ok":false,"error":"' + mvJsonEscape(String(e)) + '"}';
    }
}
